package com.rukshan.alstudy;
import android.app.*;import android.os.*;import android.graphics.Color;import android.view.*;import android.widget.*;
public class LockActivity extends Activity{
 EditText pin; @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setGravity(17);l.setPadding(35,35,35,35);l.setBackgroundColor(Color.rgb(20,18,25));TextView t=new TextView(this);t.setText("📚 STUDY MODE\n\nරුක්ෂාන්, පාඩම් කරමු ❤️");t.setTextColor(Color.WHITE);t.setTextSize(25);t.setGravity(17);l.addView(t);pin=new EditText(this);pin.setHint("Study PIN");pin.setInputType(2|16);pin.setTextColor(Color.WHITE);pin.setHintTextColor(Color.LTGRAY);l.addView(pin);Button b1=new Button(this);b1.setText("Unlock");l.addView(b1);b1.setOnClickListener(v->{String p=getSharedPreferences("data",0).getString("pin","1234");if(pin.getText().toString().equals(p)){StudyAccessibilityService.lock=false;finish();}else Toast.makeText(this,"PIN වැරදියි",Toast.LENGTH_SHORT).show();});setContentView(l);}
 @Override public void onBackPressed(){ }
}
