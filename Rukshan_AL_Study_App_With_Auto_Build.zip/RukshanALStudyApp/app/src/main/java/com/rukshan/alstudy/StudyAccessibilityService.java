package com.rukshan.alstudy;
import android.accessibilityservice.AccessibilityService;import android.content.*;import android.view.accessibility.AccessibilityEvent;
public class StudyAccessibilityService extends AccessibilityService{
 public static boolean lock=false; String own="com.rukshan.alstudy";
 @Override public void onAccessibilityEvent(AccessibilityEvent e){if(!lock)return;String p=e.getPackageName()==null?"":e.getPackageName().toString();if(p.isEmpty()||p.equals(own)||p.equals("com.android.systemui")||p.equals("com.android.settings"))return;Intent i=new Intent(this,LockActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);startActivity(i);}
 @Override public void onInterrupt(){}
}
