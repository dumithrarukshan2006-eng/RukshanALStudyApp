package com.rukshan.alstudy;

import android.Manifest;import android.app.*;import android.content.*;import android.content.pm.PackageManager;import android.graphics.Color;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;import java.text.*;import java.util.*;

public class MainActivity extends Activity {
 static boolean foreground=false; LinearLayout root, list; TextView countdown, studyTime, timer; SharedPreferences sp; Handler h=new Handler(); long paperEnd=0;
 int purple=Color.rgb(103,80,164);
 @Override public void onCreate(Bundle b){super.onCreate(b); sp=getSharedPreferences("data",0); build(); requestNotify(); AlarmReceiver.ensureChannels(this); scheduleAll();}
 @Override protected void onResume(){super.onResume();foreground=true; update();}
 @Override protected void onPause(){foreground=false;super.onPause();}
 void build(){
  root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,18,24,24);root.setBackgroundColor(Color.rgb(248,246,252));
  ScrollView sv=new ScrollView(this);sv.addView(root);setContentView(sv);
  TextView title=t("රුක්ෂාන්ගේ A/L STUDY 📚",25,true);root.addView(title);root.addView(t("Sinhala • ICT • Political Science",15,false));
  countdown=t("",42,true);countdown.setGravity(17);countdown.setTextColor(Color.rgb(190,35,75)); root.addView(card(countdown));
  root.addView(t("2027 A/L Countdown",13,false));
  Button sounds=btn("🎵 Sounds & Notifications");root.addView(sounds);sounds.setOnClickListener(v->soundDialog());
  Button timetable=btn("⏰ Timetable / Alarm +");root.addView(timetable);timetable.setOnClickListener(v->addTimetable());
  root.addView(t("📚 අදගේ වැඩ",20,true));
  String[] tasks={"කලින් දවසේ පාඩම් වැඩ නැවත බලන්න","Class Recording බැලුවා 1","Class Recording බැලුවා 2","Class Recording බැලුවා 3","Class Recording බැලුවා 4","Paper කිරීම","අලුත් කරුණු පාඩම් කිරීම"};
  for(String x:tasks) addCheck(x);
  root.addView(t("😢 අතපසු වූ වැඩ",20,true));
  Button add=btn("＋ අතපසු වූ වැඩක් Add කරන්න");root.addView(add);add.setOnClickListener(v->addMissed());
  list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);loadMissed();
  root.addView(t("🔒 Study Mode",20,true));
  Button start=btn("☑ මම පාඩම් කරන්න යනවා");root.addView(start);start.setOnClickListener(v->startStudy());
  Button finish=btn("☑ මම පාඩම්කර අවසන්");root.addView(finish);finish.setOnClickListener(v->finishStudy());
  studyTime=t("අද පාඩම් කළ කාලය: 0h 0min",17,true);root.addView(card(studyTime));
  root.addView(t("⏱️ Paper Timer",20,true));
  LinearLayout row=new LinearLayout(this); EditText min=new EditText(this);min.setHint("මිනිත්තු");min.setInputType(2); Button go=btn("▶ Start");timer=t("00:00:00",30,true);row.addView(min,new LinearLayout.LayoutParams(0,70,1));row.addView(go,new LinearLayout.LayoutParams(180,70));root.addView(row);root.addView(timer);go.setOnClickListener(v->{int m=0;try{m=Integer.parseInt(min.getText().toString());}catch(Exception e){} if(m>0){paperEnd=System.currentTimeMillis()+m*60000L;tickTimer();}});
  root.addView(t("ℹ️ පළමු වරට Study Mode සඳහා Accessibility permission එකත්, notifications/alarms සඳහා Android permissionsත් ලබා දෙන්න.",13,false));
 }
 TextView t(String s,int size,boolean bold){TextView x=new TextView(this);x.setText(s);x.setTextSize(size);x.setTextColor(Color.rgb(35,30,45));x.setPadding(8,12,8,12);if(bold)x.setTypeface(null,1);return x;}
 View card(View v){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(18,14,18,14);c.setBackgroundColor(Color.WHITE);c.addView(v);return c;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(15);b.setPadding(12,8,12,8);return b;}
 void addCheck(String s){CheckBox c=new CheckBox(this);c.setText(s);c.setTextSize(16);String k="task_"+s; c.setChecked(sp.getBoolean(k,false));c.setOnCheckedChangeListener((v,on)->{sp.edit().putBoolean(k,on).apply();});root.addView(c);}
 void update(){long start=sp.getLong("startDay",0);if(start==0){start=System.currentTimeMillis();sp.edit().putLong("startDay",start).apply();} long d=(System.currentTimeMillis()-start)/86400000L;long left=Math.max(0,153-d);countdown.setText("රුක්ෂාන්, තව දවස් "+left+" 😢💔"); long st=sp.getLong("studyStart",0);if(st>0){long sec=(System.currentTimeMillis()-st)/1000;studyTime.setText("අද පාඩම් කළ කාලය: "+(sec/3600)+"h "+((sec%3600)/60)+"min");} if(paperEnd>0){long s=Math.max(0,(paperEnd-System.currentTimeMillis())/1000);timer.setText(String.format(Locale.getDefault(),"%02d:%02d:%02d",s/3600,(s%3600)/60,s%60));}}
 void tickTimer(){update();if(paperEnd>System.currentTimeMillis())h.postDelayed(this::tickTimer,500);else{timer.setText("00:00:00");paperEnd=0;}}
 void requestNotify(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},9);}
 void scheduleAll(){AlarmReceiver.scheduleDaily(this,9,0,"countdown");AlarmReceiver.scheduleDaily(this,13,0,"countdown");AlarmReceiver.scheduleDaily(this,18,0,"countdown");AlarmReceiver.scheduleDaily(this,22,0,"countdown");AlarmReceiver.scheduleHourlyMissed(this);}
 void addTimetable(){ final EditText name=new EditText(this);name.setHint("වැඩේ නම"); final TimePicker tp=new TimePicker(this);tp.setIs24HourView(true);LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.addView(name);l.addView(tp);new AlertDialog.Builder(this).setTitle("⏰ Timetable Alarm").setView(l).setPositiveButton("Save",(d,w)->{AlarmReceiver.addTimetable(this,name.getText().toString(),tp.getHour(),tp.getMinute());Toast.makeText(this,"Alarm එක Save කළා ✅",Toast.LENGTH_SHORT).show();}).setNegativeButton("Cancel",null).show();}
 void addMissed(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);EditText name=new EditText(this);name.setHint("අතපසු වූ වැඩ");l.addView(name);Button photo=btn("📷 Photo upload");l.addView(photo);final Uri[] uri={null};photo.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,44);});new AlertDialog.Builder(this).setTitle("😢 අතපසු වූ වැඩ Add").setView(l).setPositiveButton("Add",(d,w)->{String n=name.getText().toString();if(!n.isEmpty()){sp.edit().putString("missed",n).apply();loadMissed();}}).setNegativeButton("Cancel",null).show();}
 @Override protected void onActivityResult(int r,int c,Intent data){super.onActivityResult(r,c,data);if(r==44&&c==RESULT_OK&&data!=null&&data.getData()!=null){sp.edit().putString("missedPhoto",data.getData().toString()).apply();}}
 void loadMissed(){if(list==null)return;list.removeAllViews();String m=sp.getString("missed","");if(!m.isEmpty()){TextView x=t("😢 "+m,17,true);list.addView(x);Button done=btn("✓ මේ වැඩේ අවසන්");list.addView(done);done.setOnClickListener(v->{sp.edit().remove("missed").remove("missedPhoto").apply();loadMissed();});}}
 void startStudy(){sp.edit().putLong("studyStart",System.currentTimeMillis()).apply(); StudyAccessibilityService.lock=true; if(!sp.contains("pin")){ final EditText pin=new EditText(this); pin.setHint("අලුත් PIN"); pin.setInputType(2|16); new AlertDialog.Builder(this).setTitle("Study Mode PIN").setView(pin).setPositiveButton("Save",(d,w)->{sp.edit().putString("pin",pin.getText().toString()).apply();}).show(); } Intent i=new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);startActivity(i);Toast.makeText(this,"Study Mode ON 🔒 — Accessibility එක Enable කරන්න.",Toast.LENGTH_LONG).show();}
 void finishStudy(){long st=sp.getLong("studyStart",0);if(st>0){long sec=(System.currentTimeMillis()-st)/1000;sp.edit().remove("studyStart").putLong("lastStudy",sec).apply();studyTime.setText("අද පාඩම් කළ කාලය: "+(sec/3600)+"h "+((sec%3600)/60)+"min");} StudyAccessibilityService.lock=false;Toast.makeText(this,"පාඩම් කිරීම අවසන් ✅",Toast.LENGTH_SHORT).show();}
 void soundDialog(){String[] a={"🎵 Gentle Chime","🔔 Soft Bell","⚡ Focus Beep"};new AlertDialog.Builder(this).setTitle("Sounds තෝරන්න").setItems(a,(d,w)->{sp.edit().putInt("sound",w).apply();AlarmReceiver.ensureChannels(this);Toast.makeText(this,"Sound එක වෙනස් කළා ✅",Toast.LENGTH_SHORT).show();}).show();}
}
