# Rukshan A/L Study — Android project

Features in this first build:
- 153-day A/L countdown that decreases by calendar day
- 4 daily countdown reminders (09:00, 13:00, 18:00, 22:00)
- separate notification channels for countdown, missed work, and timetable alarms
- 3 built-in simple sounds: Gentle Chime, Soft Bell, Focus Beep
- timetable alarm entry
- missed-work section + image selection + hourly reminder (suppressed while app is foreground)
- daily checklist
- Study Mode + PIN + Accessibility-based app blocking
- study time calculation
- paper countdown timer that continues when leaving the app

## Build
Open this folder in Android Studio and Build > Build APK(s).
Android 13+ notification permission and Android 12+ exact-alarm access may need to be granted in system settings.
For Study Mode, enable this app under Settings > Accessibility.

## Important
This is a functional first prototype. Android manufacturers can restrict background alarms. The final production version should add a proper alarm permission screen, boot rescheduling, recurring timetable database, per-task sounds, and stronger lock handling.
